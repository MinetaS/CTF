package androidx.localbroadcastmanager;

/* renamed from: androidx.localbroadcastmanager.R */
public final class C0257R {
    private C0257R() {
    }
}
