package androidx.lifecycle.livedata.core;

/* renamed from: androidx.lifecycle.livedata.core.R */
public final class C0252R {
    private C0252R() {
    }
}
