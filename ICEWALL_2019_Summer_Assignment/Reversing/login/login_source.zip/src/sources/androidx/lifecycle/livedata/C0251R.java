package androidx.lifecycle.livedata;

/* renamed from: androidx.lifecycle.livedata.R */
public final class C0251R {
    private C0251R() {
    }
}
