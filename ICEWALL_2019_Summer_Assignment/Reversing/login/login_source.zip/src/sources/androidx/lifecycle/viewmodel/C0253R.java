package androidx.lifecycle.viewmodel;

/* renamed from: androidx.lifecycle.viewmodel.R */
public final class C0253R {
    private C0253R() {
    }
}
